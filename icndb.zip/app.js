
let getJokesButton = document.getElementsByClassName('get-jokes')[0];

getJokesButton.addEventListener('click', getJokesFunc);


function getJokesFunc(e) {
  let jokeCount = document.getElementById('number').value;
  let requestObj = new XMLHttpRequest();
  

  if(jokeCount < 1) {
    document.querySelector('.jokes').innerHTML = "";
  }

  requestObj.open('GET', `http://api.icndb.com/jokes/random/${jokeCount}`, true);

  requestObj.onload = function () {
    let response = {}; 
    
    if(this.status == 200) {

      response = JSON.parse(this.responseText);
      let textInHTML = "";

      if(response.type === 'success') {
        for(let i in  response.value) {
          textInHTML += `<li>${response.value[i]['joke']}</li>`
        }
      } 
      else { document.querySelector('.jokes').innerHTML = ""; }

      document.querySelector('.jokes').innerHTML = textInHTML;
    }
  }
  requestObj.send();
  e.preventDefault();
} 
